<sitemapindex xmlns="http://www.sitemap.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>https://steelshotsupplier.in//sitemap.xml/product</loc>
    </sitemap>
    <sitemap>
        <loc>https://steelshotsupplier.in//sitemap.xml/category</loc>
    </sitemap>
    <sitemap>
        <loc>https://steelshotsupplier.in//sitemap.xml/blog</loc>
    </sitemap>
    <sitemap>
        <loc>https://steelshotsupplier.in//sitemap.xml/page</loc>
    </sitemap>
</sitemapindex>