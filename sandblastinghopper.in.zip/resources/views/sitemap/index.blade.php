<sitemapindex xmlns="http://www.sitemap.org/schemas/sitemap/0.9">
   <sitemap>
        <loc>{{ url('sitemap.xml/product') }}</loc>
    </sitemap>
     <sitemap>
        <loc>{{ url('sitemap.xml/category') }}</loc>
    </sitemap> <sitemap>
        <loc>{{ url('sitemap.xml/blog') }}</loc>
    </sitemap> <sitemap>
        <loc>{{ url('sitemap.xml/page') }}</loc>
    </sitemap>
</sitemapindex>